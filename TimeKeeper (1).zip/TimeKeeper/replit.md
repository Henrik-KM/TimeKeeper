# Overview

TimeTracker Pro is a professional time tracking application built with React, TypeScript, and Express. It provides comprehensive project management, time tracking, and reporting capabilities for freelancers and teams. The application features a modern dashboard with real-time timer functionality, project-based time organization, and detailed analytics.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible design
- **Styling**: Tailwind CSS with CSS custom properties for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API
- **Language**: TypeScript with ES modules for modern JavaScript features
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL session store
- **Validation**: Zod schemas for runtime type validation and API data validation

## Data Storage
- **Database**: PostgreSQL with Neon serverless for scalable cloud hosting
- **Schema**: Two main entities - projects and time entries with foreign key relationships
- **Migrations**: Drizzle Kit for database schema migrations and version control
- **Backup Strategy**: In-memory storage class for development and testing environments

## Authentication & Authorization
- **Session-based**: Express sessions with secure cookie configuration
- **Storage**: PostgreSQL session store for persistent session management
- **Security**: CORS enabled, secure headers, and environment-based configuration

## API Design
- **REST Architecture**: Conventional HTTP methods (GET, POST, PUT, DELETE) with resource-based endpoints
- **Data Validation**: Request/response validation using Zod schemas shared between client and server
- **Error Handling**: Centralized error middleware with standardized error responses
- **Response Format**: JSON responses with consistent structure and status codes

## Key Features Implementation
- **Real-time Timer**: WebSocket-like polling for live timer updates and synchronization
- **Project Management**: CRUD operations with client, budget, and deadline tracking
- **Time Tracking**: Start/stop functionality with automatic duration calculation
- **Dashboard Analytics**: Aggregated statistics, progress tracking, and performance metrics
- **Reporting**: Filtered time entries, project analytics, and export capabilities

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling and automatic scaling
- **Connection**: `@neondatabase/serverless` driver for optimized serverless connections

## UI & Design System
- **Radix UI**: Headless component primitives for accessibility and customization
- **shadcn/ui**: Pre-built component library built on Radix primitives
- **Tailwind CSS**: Utility-first CSS framework with design system integration
- **Lucide React**: Icon library with consistent styling and tree-shaking support

## Form & Validation
- **React Hook Form**: Form state management with validation integration
- **Zod**: Runtime type validation shared between client and server
- **@hookform/resolvers**: Integration layer between React Hook Form and Zod

## Date & Time Handling
- **date-fns**: Lightweight date manipulation and formatting library
- **Timezone Support**: Browser-native timezone handling with UTC storage

## Development Tools
- **TypeScript**: Static type checking with shared types between frontend and backend
- **ESBuild**: Fast bundling for production server builds
- **Vite Plugins**: Development tooling including error overlays and hot module replacement

## Deployment & Hosting
- **Replit Integration**: Development environment with live reloading and collaborative features
- **Environment Variables**: Secure configuration management for database connections and API keys