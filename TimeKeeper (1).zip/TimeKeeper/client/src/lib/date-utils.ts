import { format, formatDistanceToNow, differenceInDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";

export function formatDate(date: Date | string, formatStr = "MMM d, yyyy"): string {
  return format(new Date(date), formatStr);
}

export function formatDateTime(date: Date | string): string {
  return format(new Date(date), "MMM d, yyyy 'at' h:mm a");
}

export function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

export function formatHours(seconds: number): string {
  const hours = seconds / 3600;
  return `${hours.toFixed(1)}h`;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function getDaysLeft(deadline: Date | string): number {
  return Math.max(0, differenceInDays(new Date(deadline), new Date()));
}

export function getTimeAgo(date: Date | string): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

export function isThisWeek(date: Date | string): boolean {
  const now = new Date();
  return isWithinInterval(new Date(date), {
    start: startOfWeek(now),
    end: endOfWeek(now),
  });
}

export function isThisMonth(date: Date | string): boolean {
  const now = new Date();
  return isWithinInterval(new Date(date), {
    start: startOfMonth(now),
    end: endOfMonth(now),
  });
}

export function getWeekProgress(): number {
  const now = new Date();
  const weekStart = startOfWeek(now);
  const dayOfWeek = now.getDay();
  return (dayOfWeek / 6) * 100; // 6 working days (excluding Sunday)
}

export function getMonthProgress(): number {
  const now = new Date();
  const monthStart = startOfMonth(now);
  const monthEnd = endOfMonth(now);
  const totalDays = differenceInDays(monthEnd, monthStart) + 1;
  const daysPassed = differenceInDays(now, monthStart) + 1;
  return (daysPassed / totalDays) * 100;
}
