import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import TimeEntryForm from "@/components/time-entry-form";
import { Plus, Search, Filter, Download, Edit, Trash2, MoreHorizontal, Clock, Calendar, DollarSign } from "lucide-react";
import { formatDate, formatDateTime, formatDuration, formatCurrency } from "@/lib/date-utils";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { TimeEntryWithProject, Project } from "@shared/schema";

export default function TimeEntries() {
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [entryToDelete, setEntryToDelete] = useState<TimeEntryWithProject | null>(null);
  const [editingEntry, setEditingEntry] = useState<TimeEntryWithProject | null>(null);
  const { toast } = useToast();

  const { data: timeEntries = [], isLoading } = useQuery<TimeEntryWithProject[]>({
    queryKey: ["/api/time-entries"],
  });

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (entryId: string) => {
      await apiRequest("DELETE", `/api/time-entries/${entryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects/with-stats"] });
      toast({ title: "Time entry deleted successfully" });
      setEntryToDelete(null);
    },
    onError: () => {
      toast({ title: "Failed to delete time entry", variant: "destructive" });
    },
  });

  // Filter entries
  const filteredEntries = timeEntries.filter(entry => {
    const matchesProject = selectedProject === "all" || entry.projectId === selectedProject;
    const matchesSearch = searchTerm === "" || 
      entry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.project.client.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesProject && matchesSearch;
  });

  // Calculate statistics
  const totalHours = filteredEntries.reduce((sum, entry) => sum + (entry.duration || 0), 0) / 3600;
  const totalRevenue = filteredEntries.reduce((sum, entry) => sum + entry.total, 0);
  const todayEntries = filteredEntries.filter(entry => 
    new Date(entry.startTime).toDateString() === new Date().toDateString()
  );
  const todayHours = todayEntries.reduce((sum, entry) => sum + (entry.duration || 0), 0) / 3600;

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="space-y-6">
          <div className="h-8 bg-slate-200 rounded w-1/4 animate-pulse"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 animate-pulse">
                <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                <div className="h-6 bg-slate-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 animate-pulse">
            <div className="h-64 bg-slate-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6 space-y-6" data-testid="time-entries-page">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Time Entries</h1>
          <p className="text-slate-500 mt-1">Manage and review your time tracking records</p>
        </div>
        <TimeEntryForm
          trigger={
            <Button data-testid="button-add-time-entry">
              <Plus className="w-4 h-4 mr-2" />
              Add Entry
            </Button>
          }
        />
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Today's Hours</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="today-hours">
                  {todayHours.toFixed(1)}h
                </p>
              </div>
              <Clock className="w-8 h-8 text-primary" />
            </div>
            <div className="mt-2 text-sm text-slate-500">
              {todayEntries.length} entries today
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Hours</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="total-hours">
                  {totalHours.toFixed(1)}h
                </p>
              </div>
              <Calendar className="w-8 h-8 text-secondary" />
            </div>
            <div className="mt-2 text-sm text-slate-500">
              {filteredEntries.length} entries shown
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Revenue</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="total-revenue">
                  {formatCurrency(totalRevenue)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-accent" />
            </div>
            <div className="mt-2 text-sm text-slate-500">
              From filtered entries
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Search entries, projects, or clients..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-entries"
              />
            </div>
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger className="w-full sm:w-64" data-testid="select-filter-project">
                <SelectValue placeholder="Filter by project" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" data-testid="button-export-entries">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Time Entries Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Time Entries ({filteredEntries.length})</span>
            <Badge variant="outline" data-testid="entries-count">
              {filteredEntries.length} entries
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredEntries.length === 0 ? (
            <div className="p-8 text-center">
              <Clock className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No time entries found</h3>
              <p className="text-slate-500 mb-4">
                {searchTerm || selectedProject !== "all" 
                  ? "Try adjusting your filters to see more entries"
                  : "Get started by adding your first time entry"
                }
              </p>
              {!searchTerm && selectedProject === "all" && (
                <TimeEntryForm
                  trigger={
                    <Button data-testid="button-create-first-entry">
                      <Plus className="w-4 h-4 mr-2" />
                      Add First Entry
                    </Button>
                  }
                />
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Project</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Start Time</TableHead>
                    <TableHead>End Time</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead className="w-16">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEntries.map((entry) => (
                    <TableRow key={entry.id} className="hover:bg-slate-50">
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: entry.project.color }}
                          />
                          <div>
                            <div className="font-medium text-sm text-slate-900" data-testid="entry-project-name">
                              {entry.project.name}
                            </div>
                            <div className="text-xs text-slate-500">{entry.project.client}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-xs">
                          <div className="text-sm text-slate-900 truncate" data-testid="entry-description">
                            {entry.description}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-slate-600" data-testid="entry-start-time">
                        {formatDateTime(entry.startTime)}
                      </TableCell>
                      <TableCell className="text-sm text-slate-600" data-testid="entry-end-time">
                        {entry.endTime ? formatDateTime(entry.endTime) : (
                          <Badge variant="secondary" className="text-xs">Running</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm font-mono text-slate-900" data-testid="entry-duration">
                        {entry.duration ? formatDuration(entry.duration) : "--:--"}
                      </TableCell>
                      <TableCell className="text-sm text-slate-600" data-testid="entry-rate">
                        {formatCurrency(parseFloat(entry.project.hourlyRate))}/hr
                      </TableCell>
                      <TableCell className="text-sm font-medium text-slate-900" data-testid="entry-total">
                        {formatCurrency(entry.total)}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" data-testid="button-entry-menu">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem 
                              onClick={() => setEditingEntry(entry)}
                              data-testid="menu-edit-entry"
                            >
                              <Edit className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => setEntryToDelete(entry)}
                              className="text-destructive"
                              data-testid="menu-delete-entry"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Entry Dialog */}
      {editingEntry && (
        <TimeEntryForm
          entry={{
            id: editingEntry.id,
            projectId: editingEntry.projectId,
            description: editingEntry.description,
            startTime: editingEntry.startTime,
            endTime: editingEntry.endTime,
            duration: editingEntry.duration,
            isRunning: editingEntry.isRunning,
            createdAt: editingEntry.createdAt,
          }}
          trigger={<div />}
          onSuccess={() => setEditingEntry(null)}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!entryToDelete} onOpenChange={() => setEntryToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Time Entry</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this time entry? This action cannot be undone.
              <div className="mt-3 p-3 bg-slate-50 rounded-lg">
                <div className="font-medium text-sm">{entryToDelete?.project.name}</div>
                <div className="text-sm text-slate-600">{entryToDelete?.description}</div>
                <div className="text-xs text-slate-500 mt-1">
                  {entryToDelete && formatDate(entryToDelete.startTime)} • {entryToDelete && formatDuration(entryToDelete.duration || 0)}
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-entry">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => entryToDelete && deleteMutation.mutate(entryToDelete.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete-entry"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
