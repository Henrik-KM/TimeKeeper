import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Download, TrendingUp, Clock, DollarSign, Target } from "lucide-react";
import { formatCurrency, formatDate, formatHours } from "@/lib/date-utils";
import type { ProjectWithStats, DashboardStats } from "@shared/schema";

export default function Reports() {
  const { data: projects = [] } = useQuery<ProjectWithStats[]>({
    queryKey: ["/api/projects/with-stats"],
  });

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const sortedProjects = [...projects].sort((a, b) => b.totalRevenue - a.totalRevenue);
  const topProjects = sortedProjects.slice(0, 5);

  return (
    <div className="flex-1 p-6 space-y-6" data-testid="reports-page">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reports & Analytics</h1>
          <p className="text-slate-500 mt-1">Track your productivity and performance</p>
        </div>
        <div className="flex items-center space-x-3">
          <Select defaultValue="this-month">
            <SelectTrigger className="w-40" data-testid="select-time-period">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this-week">This Week</SelectItem>
              <SelectItem value="this-month">This Month</SelectItem>
              <SelectItem value="last-month">Last Month</SelectItem>
              <SelectItem value="this-year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button data-testid="button-export-report">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Hours</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="total-hours-metric">
                  {projects.reduce((sum, p) => sum + p.totalHours, 0).toFixed(1)}h
                </p>
              </div>
              <Clock className="w-8 h-8 text-primary" />
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-secondary mr-1" />
              <span className="text-secondary">+12%</span>
              <span className="text-slate-500 ml-2">vs last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Revenue</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="total-revenue-metric">
                  {formatCurrency(projects.reduce((sum, p) => sum + p.totalRevenue, 0))}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-secondary" />
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-secondary mr-1" />
              <span className="text-secondary">+18%</span>
              <span className="text-slate-500 ml-2">vs last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Avg Hourly Rate</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="avg-hourly-rate">
                  {formatCurrency(
                    projects.length > 0 
                      ? projects.reduce((sum, p) => sum + parseFloat(p.hourlyRate), 0) / projects.length
                      : 0
                  )}
                </p>
              </div>
              <Target className="w-8 h-8 text-accent" />
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-slate-500">Across all projects</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Active Projects</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="active-projects-metric">
                  {projects.filter(p => p.isActive).length}
                </p>
              </div>
              <Calendar className="w-8 h-8 text-primary" />
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-slate-500">
                {projects.filter(p => !p.isActive).length} completed
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Project Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performing Projects */}
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Projects</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topProjects.map((project, index) => (
                <div key={project.id} className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="text-sm font-medium text-slate-500 w-6">
                      #{index + 1}
                    </div>
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: project.color }}
                    />
                    <div>
                      <div className="font-medium text-sm text-slate-900" data-testid="top-project-name">
                        {project.name}
                      </div>
                      <div className="text-xs text-slate-500">{project.client}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-sm text-slate-900" data-testid="top-project-revenue">
                      {formatCurrency(project.totalRevenue)}
                    </div>
                    <div className="text-xs text-slate-500">
                      {project.totalHours.toFixed(1)}h
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Project Status Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Project Status Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {projects.slice(0, 5).map((project) => (
                <div key={project.id} className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: project.color }}
                    />
                    <div>
                      <div className="font-medium text-sm text-slate-900">
                        {project.name}
                      </div>
                      <div className="text-xs text-slate-500">
                        {project.totalHours.toFixed(1)}h / {parseFloat(project.budgetHours).toFixed(0)}h
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-slate-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full bg-primary"
                        style={{ width: `${Math.min(100, project.budgetProgress)}%` }}
                      />
                    </div>
                    <Badge 
                      variant={
                        project.status === 'ahead' ? 'default' :
                        project.status === 'behind' ? 'destructive' : 'secondary'
                      }
                      className="text-xs"
                    >
                      {project.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Project Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Project Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Project</th>
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Client</th>
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Hours</th>
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Budget</th>
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Revenue</th>
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Progress</th>
                  <th className="text-left p-3 text-sm font-medium text-slate-500">Status</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((project) => (
                  <tr key={project.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: project.color }}
                        />
                        <span className="font-medium text-sm text-slate-900" data-testid="breakdown-project-name">
                          {project.name}
                        </span>
                      </div>
                    </td>
                    <td className="p-3 text-sm text-slate-600" data-testid="breakdown-client">
                      {project.client}
                    </td>
                    <td className="p-3 text-sm text-slate-900 font-mono" data-testid="breakdown-hours">
                      {project.totalHours.toFixed(1)}h
                    </td>
                    <td className="p-3 text-sm text-slate-600" data-testid="breakdown-budget">
                      {parseFloat(project.budgetHours).toFixed(0)}h
                    </td>
                    <td className="p-3 text-sm text-slate-900 font-medium" data-testid="breakdown-revenue">
                      {formatCurrency(project.totalRevenue)}
                    </td>
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-16 bg-slate-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-primary"
                            style={{ width: `${Math.min(100, project.budgetProgress)}%` }}
                          />
                        </div>
                        <span className="text-xs text-slate-500">
                          {project.budgetProgress.toFixed(0)}%
                        </span>
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge 
                        variant={
                          project.status === 'ahead' ? 'default' :
                          project.status === 'behind' ? 'destructive' : 'secondary'
                        }
                        className="text-xs"
                      >
                        {project.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
