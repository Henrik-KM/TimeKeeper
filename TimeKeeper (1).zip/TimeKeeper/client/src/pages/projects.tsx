import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import ProjectForm from "@/components/project-form";
import ProjectCard from "@/components/project-card";
import { Plus, FolderOpen, Calendar, DollarSign } from "lucide-react";
import { formatCurrency, formatDate, getDaysLeft } from "@/lib/date-utils";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { ProjectWithStats } from "@shared/schema";

export default function Projects() {
  const [projectToDelete, setProjectToDelete] = useState<ProjectWithStats | null>(null);
  const { toast } = useToast();

  const { data: projects = [], isLoading } = useQuery<ProjectWithStats[]>({
    queryKey: ["/api/projects/with-stats"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (projectId: string) => {
      await apiRequest("DELETE", `/api/projects/${projectId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects/with-stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Project deleted successfully" });
      setProjectToDelete(null);
    },
    onError: () => {
      toast({ title: "Failed to delete project", variant: "destructive" });
    },
  });

  const activeProjects = projects.filter(p => p.isActive);
  const completedProjects = projects.filter(p => !p.isActive);

  const totalRevenue = projects.reduce((sum, p) => sum + p.totalRevenue, 0);
  const totalHours = projects.reduce((sum, p) => sum + p.totalHours, 0);

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 animate-pulse">
              <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-slate-200 rounded w-1/2 mb-4"></div>
              <div className="space-y-3">
                <div className="h-2 bg-slate-200 rounded"></div>
                <div className="h-2 bg-slate-200 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6 space-y-6" data-testid="projects-page">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Projects</h1>
          <p className="text-slate-500 mt-1">Manage your projects and track progress</p>
        </div>
        <ProjectForm
          trigger={
            <Button data-testid="button-add-project">
              <Plus className="w-4 h-4 mr-2" />
              Add Project
            </Button>
          }
        />
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Active Projects</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="active-projects-count">
                  {activeProjects.length}
                </p>
              </div>
              <FolderOpen className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Hours</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="total-hours">
                  {totalHours.toFixed(1)}h
                </p>
              </div>
              <Calendar className="w-8 h-8 text-secondary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Revenue</p>
                <p className="text-2xl font-bold text-slate-900" data-testid="total-revenue">
                  {formatCurrency(totalRevenue)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-accent" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Projects */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-4">
          Active Projects ({activeProjects.length})
        </h2>
        
        {activeProjects.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <FolderOpen className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No active projects</h3>
              <p className="text-slate-500 mb-4">Get started by creating your first project</p>
              <ProjectForm
                trigger={
                  <Button data-testid="button-create-first-project">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Project
                  </Button>
                }
              />
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {activeProjects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onEdit={(project) => console.log('Edit project:', project)}
                onDelete={(project) => setProjectToDelete(project)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Completed Projects */}
      {completedProjects.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Completed Projects ({completedProjects.length})
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {completedProjects.map((project) => (
              <div key={project.id} className="project-card opacity-75">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-slate-900">
                      {project.name}
                    </h3>
                    <p className="text-sm text-slate-500">{project.client}</p>
                    <div className="flex items-center mt-2 space-x-4 text-sm text-slate-600">
                      <span>{formatCurrency(parseFloat(project.hourlyRate))}/hr</span>
                      <span>•</span>
                      <span>Completed {formatDate(project.deadline)}</span>
                    </div>
                  </div>
                  <Badge variant="secondary">Completed</Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Total Hours:</span>
                    <span>{project.totalHours.toFixed(1)}h</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Total Revenue:</span>
                    <span>{formatCurrency(project.totalRevenue)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!projectToDelete} onOpenChange={() => setProjectToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Project</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{projectToDelete?.name}"? This action cannot be undone 
              and will also delete all associated time entries.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => projectToDelete && deleteMutation.mutate(projectToDelete.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
