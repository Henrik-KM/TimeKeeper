import { useQuery } from "@tanstack/react-query";
import TimerHeader from "@/components/timer-header";
import StatsCard from "@/components/stats-card";
import ProjectCard from "@/components/project-card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Clock, Calendar, FolderOpen, DollarSign, Edit, Trash2, Filter, Download } from "lucide-react";
import { formatDate, formatDuration, formatCurrency } from "@/lib/date-utils";
import type { DashboardStats, ProjectWithStats, TimeEntryWithProject } from "@shared/schema";

export default function Dashboard() {
  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: projects = [] } = useQuery<ProjectWithStats[]>({
    queryKey: ["/api/projects/with-stats"],
  });

  const { data: timeEntries = [] } = useQuery<TimeEntryWithProject[]>({
    queryKey: ["/api/time-entries"],
  });

  const recentEntries = timeEntries.slice(0, 4);

  return (
    <div className="flex flex-col h-full">
      <TimerHeader />
      
      <div className="flex-1 p-6 space-y-6" data-testid="dashboard-content">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard
            title="Today's Hours"
            value={`${stats?.todayHours.toFixed(1) || '0.0'}h`}
            icon={Clock}
            change={{
              value: "12%",
              type: "positive",
              label: "vs yesterday"
            }}
          />
          
          <StatsCard
            title="This Week"
            value={`${stats?.weekHours.toFixed(0) || '0'}/${stats?.weekTarget || 40}h`}
            icon={Calendar}
            progress={{
              value: stats?.weeklyProgress || 0,
              label: `${((stats?.weeklyProgress || 0)).toFixed(1)}% of target`
            }}
          />
          
          <StatsCard
            title="Active Projects"
            value={stats?.activeProjects.toString() || '0'}
            icon={FolderOpen}
            change={{
              value: "3 due this week",
              type: "neutral",
              label: ""
            }}
          />
          
          <StatsCard
            title="Revenue"
            value={formatCurrency(stats?.totalRevenue || 0)}
            icon={DollarSign}
            change={{
              value: "8%",
              type: "positive",
              label: "this month"
            }}
          />
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onEdit={(project) => console.log('Edit project:', project)}
              onDelete={(project) => console.log('Delete project:', project)}
            />
          ))}
        </div>

        {/* Recent Time Entries */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-900" data-testid="recent-entries-title">
                Recent Time Entries
              </h2>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" data-testid="button-filter">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
                <Button size="sm" data-testid="button-export">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Project</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentEntries.map((entry) => (
                  <TableRow key={entry.id} className="hover:bg-slate-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div 
                          className="flex-shrink-0 h-3 w-3 rounded-full mr-3"
                          style={{ backgroundColor: entry.project.color }}
                        />
                        <div className="text-sm font-medium text-slate-900" data-testid="entry-project">
                          {entry.project.name}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-slate-900" data-testid="entry-description">
                        {entry.description}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-slate-500" data-testid="entry-date">
                      {formatDate(entry.startTime)}
                    </TableCell>
                    <TableCell className="text-sm font-mono text-slate-900" data-testid="entry-duration">
                      {formatDuration(entry.duration || 0)}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500" data-testid="entry-rate">
                      {formatCurrency(parseFloat(entry.project.hourlyRate))}/hr
                    </TableCell>
                    <TableCell className="text-sm font-medium text-slate-900" data-testid="entry-total">
                      {formatCurrency(entry.total)}
                    </TableCell>
                    <TableCell className="text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" data-testid="button-edit-entry">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" data-testid="button-delete-entry">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {timeEntries.length > 4 && (
            <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-between">
              <div className="text-sm text-slate-500">
                Showing 4 of {timeEntries.length} entries
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" disabled data-testid="button-previous">
                  Previous
                </Button>
                <Button variant="outline" size="sm" className="bg-primary text-white">
                  1
                </Button>
                <Button variant="outline" size="sm" data-testid="button-page-2">
                  2
                </Button>
                <Button variant="outline" size="sm" data-testid="button-next">
                  Next
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
