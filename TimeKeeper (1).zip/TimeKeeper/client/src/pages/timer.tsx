import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import TimerHeader from "@/components/timer-header";
import { useTimer } from "@/hooks/use-timer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Play, Pause, Square, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDate, formatDuration } from "@/lib/date-utils";
import type { Project, TimeEntry } from "@shared/schema";

export default function Timer() {
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [description, setDescription] = useState("");

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: recentEntries = [] } = useQuery<TimeEntry[]>({
    queryKey: ["/api/time-entries"],
  });

  const {
    runningEntry,
    isRunning,
    formattedTime,
    toggleTimer,
    isStarting,
    isStopping,
  } = useTimer();

  const activeProjects = projects.filter(p => p.isActive);
  const todayEntries = recentEntries.slice(0, 5);

  const handleStartTimer = () => {
    if (selectedProjectId) {
      toggleTimer(selectedProjectId, description);
      setDescription("");
    }
  };

  const currentProject = runningEntry 
    ? projects.find(p => p.id === runningEntry.projectId)
    : null;

  return (
    <div className="flex flex-col h-full">
      <TimerHeader />
      
      <div className="flex-1 p-6 space-y-6" data-testid="timer-page">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Timer Control */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>Time Tracker</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Timer Display */}
              <div className="text-center py-8">
                <div className="text-6xl font-mono font-bold text-slate-900 mb-2" data-testid="large-timer-display">
                  {formattedTime}
                </div>
                {currentProject && (
                  <div className="text-lg text-slate-600" data-testid="current-timer-project">
                    {currentProject.name}
                  </div>
                )}
                {runningEntry?.description && (
                  <div className="text-sm text-slate-500 mt-1" data-testid="current-timer-description">
                    {runningEntry.description}
                  </div>
                )}
              </div>

              {/* Timer Controls */}
              {isRunning ? (
                <div className="space-y-4">
                  <Button
                    onClick={() => toggleTimer()}
                    disabled={isStopping}
                    className="w-full h-12 bg-red-500 hover:bg-red-600 text-white"
                    data-testid="button-stop-timer"
                  >
                    <Square className="w-5 h-5 mr-2" />
                    {isStopping ? "Stopping..." : "Stop Timer"}
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                    <SelectTrigger data-testid="select-timer-project">
                      <SelectValue placeholder="Select a project" />
                    </SelectTrigger>
                    <SelectContent>
                      {activeProjects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          <div className="flex items-center space-x-2">
                            <div 
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: project.color }}
                            />
                            <span>{project.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Textarea
                    placeholder="What are you working on? (optional)"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="min-h-[80px]"
                    data-testid="input-timer-description"
                  />

                  <Button
                    onClick={handleStartTimer}
                    disabled={!selectedProjectId || isStarting}
                    className="w-full h-12 bg-green-500 hover:bg-green-600 text-white"
                    data-testid="button-start-timer"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    {isStarting ? "Starting..." : "Start Timer"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Today's Entries */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Today's Time Entries</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {todayEntries.length === 0 ? (
                  <p className="text-slate-500 text-center py-4" data-testid="no-entries-message">
                    No time entries yet today
                  </p>
                ) : (
                  todayEntries.map((entry) => {
                    const project = projects.find(p => p.id === entry.projectId);
                    return (
                      <div 
                        key={entry.id} 
                        className="flex items-center justify-between p-3 border border-slate-200 rounded-lg"
                        data-testid="entry-item"
                      >
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: project?.color || '#64748b' }}
                          />
                          <div>
                            <div className="font-medium text-sm text-slate-900">
                              {project?.name || 'Unknown Project'}
                            </div>
                            <div className="text-xs text-slate-500">
                              {entry.description}
                            </div>
                          </div>
                        </div>
                        <div className="text-sm font-mono text-slate-600" data-testid="entry-duration">
                          {formatDuration(entry.duration || 0)}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-slate-900">7.5h</div>
                <div className="text-sm text-slate-500">Today's Total</div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-slate-900">35h</div>
                <div className="text-sm text-slate-500">This Week</div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-slate-900">$3,240</div>
                <div className="text-sm text-slate-500">Week's Revenue</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
