import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { TimeEntry } from "@shared/schema";

export function useTimer() {
  const [elapsedTime, setElapsedTime] = useState(0);

  const { data: runningEntry, isLoading } = useQuery({
    queryKey: ["/api/time-entries/running"],
    refetchInterval: 1000,
  });

  const startTimerMutation = useMutation({
    mutationFn: async ({ projectId, description }: { projectId: string; description?: string }) => {
      const response = await apiRequest("POST", "/api/timer/start", { projectId, description });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries/running"] });
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
  });

  const stopTimerMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/timer/stop");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries/running"] });
      queryClient.invalidateQueries({ queryKey: ["/api/time-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects/with-stats"] });
    },
  });

  const startTimer = useCallback((projectId: string, description?: string) => {
    startTimerMutation.mutate({ projectId, description });
  }, [startTimerMutation]);

  const stopTimer = useCallback(() => {
    stopTimerMutation.mutate();
  }, [stopTimerMutation]);

  const toggleTimer = useCallback((projectId?: string, description?: string) => {
    if (runningEntry) {
      stopTimer();
    } else if (projectId) {
      startTimer(projectId, description);
    }
  }, [runningEntry, startTimer, stopTimer]);

  // Calculate elapsed time for running timer
  useEffect(() => {
    if (runningEntry?.isRunning) {
      const interval = setInterval(() => {
        const startTime = new Date(runningEntry.startTime).getTime();
        const now = Date.now();
        const elapsed = Math.floor((now - startTime) / 1000);
        setElapsedTime(elapsed);
      }, 1000);

      return () => clearInterval(interval);
    } else {
      setElapsedTime(0);
    }
  }, [runningEntry]);

  const formatTime = useCallback((seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  return {
    runningEntry: runningEntry as TimeEntry | null,
    isRunning: Boolean(runningEntry?.isRunning),
    elapsedTime,
    formattedTime: formatTime(elapsedTime),
    startTimer,
    stopTimer,
    toggleTimer,
    isLoading,
    isStarting: startTimerMutation.isPending,
    isStopping: stopTimerMutation.isPending,
  };
}
