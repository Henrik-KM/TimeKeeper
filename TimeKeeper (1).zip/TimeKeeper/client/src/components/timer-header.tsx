import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTimer } from "@/hooks/use-timer";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Play, Pause, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Project } from "@shared/schema";

export default function TimerHeader() {
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [description, setDescription] = useState("");
  
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const {
    runningEntry,
    isRunning,
    formattedTime,
    toggleTimer,
    isStarting,
    isStopping,
  } = useTimer();

  const currentProject = runningEntry 
    ? projects.find(p => p.id === runningEntry.projectId)
    : projects.find(p => p.id === selectedProjectId);

  const handleToggleTimer = () => {
    if (isRunning) {
      toggleTimer();
    } else if (selectedProjectId) {
      toggleTimer(selectedProjectId, description);
    }
  };

  const canStart = !isRunning && selectedProjectId;
  const isLoading = isStarting || isStopping;

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4" data-testid="timer-header">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <Button
              onClick={handleToggleTimer}
              disabled={!canStart && !isRunning || isLoading}
              className={cn(
                "timer-button",
                isRunning ? "timer-button running" : "timer-button stopped"
              )}
              data-testid="button-toggle-timer"
            >
              {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </Button>
            <div>
              <div className="timer-display" data-testid="timer-display">
                {formattedTime}
              </div>
              <div className="text-sm text-slate-500" data-testid="current-project">
                {currentProject ? `${currentProject.name} - ${runningEntry?.description || description || 'No description'}` : 'No project selected'}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {!isRunning && (
            <>
              <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                <SelectTrigger className="w-64" data-testid="select-project">
                  <SelectValue placeholder="Select a project" />
                </SelectTrigger>
                <SelectContent>
                  {projects.filter(p => p.isActive).map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Task description (optional)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-64"
                data-testid="input-description"
              />
            </>
          )}
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
            data-testid="button-new-entry"
          >
            <Plus className="w-4 h-4" />
            <span>New Entry</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
