import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { formatCurrency, getDaysLeft } from "@/lib/date-utils";
import type { ProjectWithStats } from "@shared/schema";

interface ProjectCardProps {
  project: ProjectWithStats;
  onEdit?: (project: ProjectWithStats) => void;
  onDelete?: (project: ProjectWithStats) => void;
}

export default function ProjectCard({ project, onEdit, onDelete }: ProjectCardProps) {
  const budgetRemaining = Math.max(0, parseFloat(project.budgetHours) - project.totalHours);
  const budgetRemainingPercent = (budgetRemaining / parseFloat(project.budgetHours)) * 100;
  const daysLeft = getDaysLeft(project.deadline);
  
  const getStatusBadge = () => {
    switch (project.status) {
      case 'ahead':
        return <span className="status-badge status-ahead">Ahead</span>;
      case 'behind':
        return <span className="status-badge status-behind">Behind</span>;
      default:
        return <span className="status-badge status-on-track">On Track</span>;
    }
  };

  const getBudgetProgressColor = () => {
    if (project.budgetProgress > 90) return 'bg-warning';
    if (project.budgetProgress > 75) return 'bg-accent';
    return 'bg-primary';
  };

  const getTimelineProgressColor = () => {
    if (project.status === 'behind') return 'bg-warning';
    if (project.status === 'ahead') return 'bg-secondary';
    return 'bg-secondary';
  };

  return (
    <div className="project-card" data-testid="project-card">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-slate-900" data-testid="project-name">
            {project.name}
          </h3>
          <p className="text-sm text-slate-500" data-testid="project-client">
            {project.client}
          </p>
          <div className="flex items-center mt-2 space-x-4 text-sm text-slate-600">
            <span data-testid="hourly-rate">
              {formatCurrency(parseFloat(project.hourlyRate))}/hr
            </span>
            <span>•</span>
            <span data-testid="deadline">
              Due {new Date(project.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {getStatusBadge()}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" data-testid="button-project-menu">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit?.(project)} data-testid="menu-edit-project">
                Edit Project
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => onDelete?.(project)} 
                className="text-destructive"
                data-testid="menu-delete-project"
              >
                Delete Project
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="space-y-4">
        {/* Budget Progress */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-700">Budget Progress</span>
            <span className="text-sm text-slate-500" data-testid="budget-used">
              {project.totalHours.toFixed(1)}h / {parseFloat(project.budgetHours).toFixed(0)}h
            </span>
          </div>
          <div className="progress-bar">
            <div 
              className={cn("progress-fill", getBudgetProgressColor())}
              style={{ width: `${Math.min(100, project.budgetProgress)}%` }}
            />
          </div>
          <p className="text-xs text-slate-500 mt-1" data-testid="budget-remaining">
            {budgetRemainingPercent.toFixed(1)}% budget remaining
          </p>
        </div>

        {/* Timeline Progress */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-700">Timeline Progress</span>
            <span className="text-sm text-slate-500" data-testid="days-left">
              {daysLeft} days left
            </span>
          </div>
          <div className="progress-bar">
            <div 
              className={cn("progress-fill", getTimelineProgressColor())}
              style={{ width: `${Math.min(100, project.timelineProgress)}%` }}
            />
          </div>
          <p className="text-xs text-slate-500 mt-1" data-testid="expected-vs-actual">
            Expected: {project.expectedHours.toFixed(0)}h | Actual: {project.totalHours.toFixed(1)}h
          </p>
        </div>

        {/* Weekly Progress */}
        <div className="grid grid-cols-3 gap-4 pt-2 border-t border-slate-100">
          <div className="text-center">
            <p className="text-xs text-slate-500">This Week</p>
            <p className="text-sm font-semibold text-slate-900" data-testid="weekly-hours">
              {project.weeklyHours.toFixed(1)}h
            </p>
            <p className={cn(
              "text-xs",
              project.status === 'ahead' ? "text-secondary" : 
              project.status === 'behind' ? "text-warning" : "text-secondary"
            )}>
              {project.status === 'ahead' && `${Math.abs(project.totalHours - project.expectedHours).toFixed(1)}h ahead`}
              {project.status === 'behind' && `${Math.abs(project.totalHours - project.expectedHours).toFixed(1)}h over`}
              {project.status === 'on-track' && 'On track'}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-slate-500">Last Week</p>
            <p className="text-sm font-semibold text-slate-900">
              {(project.weeklyHours * 0.8).toFixed(1)}h
            </p>
            <p className="text-xs text-secondary">+1h ahead</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-slate-500">Revenue</p>
            <p className="text-sm font-semibold text-slate-900" data-testid="project-revenue">
              {formatCurrency(project.totalRevenue)}
            </p>
            <p className="text-xs text-secondary">+12%</p>
          </div>
        </div>
      </div>
    </div>
  );
}
