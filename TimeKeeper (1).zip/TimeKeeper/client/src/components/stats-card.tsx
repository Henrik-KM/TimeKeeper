import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  change?: {
    value: string;
    type: 'positive' | 'negative' | 'neutral';
    label: string;
  };
  progress?: {
    value: number;
    label: string;
  };
  className?: string;
}

export default function StatsCard({ 
  title, 
  value, 
  icon: Icon, 
  change, 
  progress,
  className 
}: StatsCardProps) {
  return (
    <div className={cn("stat-card", className)} data-testid="stats-card">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500" data-testid="stats-title">{title}</p>
          <p className="text-2xl font-bold text-slate-900" data-testid="stats-value">{value}</p>
        </div>
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon className="text-primary" size={24} />
        </div>
      </div>
      
      {progress && (
        <div className="mt-4">
          <div className="progress-bar">
            <div 
              className="progress-fill bg-secondary" 
              style={{ width: `${Math.min(100, progress.value)}%` }}
            />
          </div>
          <p className="text-sm text-slate-500 mt-2" data-testid="progress-label">{progress.label}</p>
        </div>
      )}
      
      {change && (
        <div className="mt-4 flex items-center text-sm">
          <span 
            className={cn(
              change.type === 'positive' && "text-secondary",
              change.type === 'negative' && "text-warning",
              change.type === 'neutral' && "text-slate-500"
            )}
            data-testid="change-value"
          >
            {change.type === 'positive' && '↗ '}
            {change.type === 'negative' && '↘ '}
            {change.value}
          </span>
          <span className="text-slate-500 ml-2" data-testid="change-label">{change.label}</span>
        </div>
      )}
    </div>
  );
}
