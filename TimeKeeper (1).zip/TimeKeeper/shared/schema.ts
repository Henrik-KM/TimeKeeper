import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  client: text("client").notNull(),
  description: text("description"),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }).notNull(),
  budgetHours: decimal("budget_hours", { precision: 10, scale: 2 }).notNull(),
  deadline: timestamp("deadline").notNull(),
  color: text("color").notNull().default("#2563EB"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const timeEntries = pgTable("time_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in seconds
  isRunning: boolean("is_running").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});

export const insertTimeEntrySchema = createInsertSchema(timeEntries).omit({
  id: true,
  createdAt: true,
});

export const updateTimeEntrySchema = insertTimeEntrySchema.partial();

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertTimeEntry = z.infer<typeof insertTimeEntrySchema>;
export type UpdateTimeEntry = z.infer<typeof updateTimeEntrySchema>;
export type Project = typeof projects.$inferSelect;
export type TimeEntry = typeof timeEntries.$inferSelect;

// Extended types for API responses
export type ProjectWithStats = Project & {
  totalHours: number;
  totalRevenue: number;
  budgetProgress: number;
  timelineProgress: number;
  weeklyHours: number;
  expectedHours: number;
  status: 'ahead' | 'on-track' | 'behind';
  daysLeft: number;
  weeklyProgress: number;
  monthlyProgress: number;
};

export type TimeEntryWithProject = TimeEntry & {
  project: Project;
  total: number;
};

export type DashboardStats = {
  todayHours: number;
  weekHours: number;
  weekTarget: number;
  activeProjects: number;
  totalRevenue: number;
  weeklyProgress: number;
  monthlyProgress: number;
};
