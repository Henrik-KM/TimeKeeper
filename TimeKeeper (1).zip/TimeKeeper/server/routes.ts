import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertTimeEntrySchema, updateTimeEntrySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/with-stats", async (req, res) => {
    try {
      const projects = await storage.getProjectsWithStats();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects with stats" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(req.params.id, validatedData);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteProject(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Time Entries
  app.get("/api/time-entries", async (req, res) => {
    try {
      const entries = await storage.getTimeEntriesWithProjects();
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time entries" });
    }
  });

  app.get("/api/time-entries/running", async (req, res) => {
    try {
      const entry = await storage.getRunningTimeEntry();
      res.json(entry || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch running time entry" });
    }
  });

  app.get("/api/time-entries/:id", async (req, res) => {
    try {
      const entry = await storage.getTimeEntry(req.params.id);
      if (!entry) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time entry" });
    }
  });

  app.post("/api/time-entries", async (req, res) => {
    try {
      const validatedData = insertTimeEntrySchema.parse(req.body);
      const entry = await storage.createTimeEntry(validatedData);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create time entry" });
    }
  });

  app.put("/api/time-entries/:id", async (req, res) => {
    try {
      const validatedData = updateTimeEntrySchema.parse(req.body);
      const entry = await storage.updateTimeEntry(req.params.id, validatedData);
      if (!entry) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update time entry" });
    }
  });

  app.delete("/api/time-entries/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTimeEntry(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete time entry" });
    }
  });

  // Timer actions
  app.post("/api/timer/start", async (req, res) => {
    try {
      const { projectId, description = "" } = req.body;
      
      if (!projectId) {
        return res.status(400).json({ message: "Project ID is required" });
      }

      // Stop any currently running timer
      const runningEntry = await storage.getRunningTimeEntry();
      if (runningEntry) {
        const endTime = new Date();
        const duration = Math.floor((endTime.getTime() - new Date(runningEntry.startTime).getTime()) / 1000);
        await storage.updateTimeEntry(runningEntry.id, {
          endTime,
          duration,
          isRunning: false,
        });
      }

      // Start new timer
      const newEntry = await storage.createTimeEntry({
        projectId,
        description,
        startTime: new Date(),
        endTime: null,
        duration: null,
        isRunning: true,
      });

      res.json(newEntry);
    } catch (error) {
      res.status(500).json({ message: "Failed to start timer" });
    }
  });

  app.post("/api/timer/stop", async (req, res) => {
    try {
      const runningEntry = await storage.getRunningTimeEntry();
      if (!runningEntry) {
        return res.status(404).json({ message: "No running timer found" });
      }

      const endTime = new Date();
      const duration = Math.floor((endTime.getTime() - new Date(runningEntry.startTime).getTime()) / 1000);
      
      const updatedEntry = await storage.updateTimeEntry(runningEntry.id, {
        endTime,
        duration,
        isRunning: false,
      });

      res.json(updatedEntry);
    } catch (error) {
      res.status(500).json({ message: "Failed to stop timer" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
