import { type Project, type TimeEntry, type InsertProject, type InsertTimeEntry, type UpdateTimeEntry, type ProjectWithStats, type TimeEntryWithProject, type DashboardStats } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  getProjectsWithStats(): Promise<ProjectWithStats[]>;

  // Time Entries
  getTimeEntries(): Promise<TimeEntry[]>;
  getTimeEntry(id: string): Promise<TimeEntry | undefined>;
  getTimeEntriesWithProjects(): Promise<TimeEntryWithProject[]>;
  getTimeEntriesForProject(projectId: string): Promise<TimeEntry[]>;
  createTimeEntry(timeEntry: InsertTimeEntry): Promise<TimeEntry>;
  updateTimeEntry(id: string, timeEntry: UpdateTimeEntry): Promise<TimeEntry | undefined>;
  deleteTimeEntry(id: string): Promise<boolean>;
  getRunningTimeEntry(): Promise<TimeEntry | undefined>;
  
  // Dashboard
  getDashboardStats(): Promise<DashboardStats>;
}

export class MemStorage implements IStorage {
  private projects: Map<string, Project> = new Map();
  private timeEntries: Map<string, TimeEntry> = new Map();

  constructor() {
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample projects
    const project1: Project = {
      id: "proj-1",
      name: "Website Redesign",
      client: "Acme Corporation",
      description: "Complete website redesign with modern UI/UX",
      hourlyRate: "85.00",
      budgetHours: "80.00",
      deadline: new Date("2024-12-15"),
      color: "#2563EB",
      isActive: true,
      createdAt: new Date(),
    };

    const project2: Project = {
      id: "proj-2",
      name: "Mobile App Development",
      client: "TechStart Inc.",
      description: "Native mobile app for iOS and Android",
      hourlyRate: "95.00",
      budgetHours: "120.00",
      deadline: new Date("2025-01-20"),
      color: "#EF4444",
      isActive: true,
      createdAt: new Date(),
    };

    const project3: Project = {
      id: "proj-3",
      name: "Brand Identity Project",
      client: "Creative Agency",
      description: "Complete brand identity and guidelines",
      hourlyRate: "75.00",
      budgetHours: "50.00",
      deadline: new Date("2024-11-30"),
      color: "#10B981",
      isActive: true,
      createdAt: new Date(),
    };

    const project4: Project = {
      id: "proj-4",
      name: "E-commerce Platform",
      client: "Retail Solutions",
      description: "Custom e-commerce platform development",
      hourlyRate: "100.00",
      budgetHours: "160.00",
      deadline: new Date("2025-02-10"),
      color: "#8B5CF6",
      isActive: true,
      createdAt: new Date(),
    };

    this.projects.set(project1.id, project1);
    this.projects.set(project2.id, project2);
    this.projects.set(project3.id, project3);
    this.projects.set(project4.id, project4);

    // Sample time entries
    const entries = [
      {
        id: "entry-1",
        projectId: "proj-1",
        description: "Frontend development and responsive design implementation",
        startTime: new Date("2024-11-08T09:00:00"),
        endTime: new Date("2024-11-08T12:45:00"),
        duration: 13500, // 3h 45m
        isRunning: false,
        createdAt: new Date(),
      },
      {
        id: "entry-2",
        projectId: "proj-2",
        description: "API integration and user authentication",
        startTime: new Date("2024-11-08T14:00:00"),
        endTime: new Date("2024-11-08T16:30:00"),
        duration: 9000, // 2h 30m
        isRunning: false,
        createdAt: new Date(),
      },
      {
        id: "entry-3",
        projectId: "proj-3",
        description: "Logo design iterations and brand guidelines",
        startTime: new Date("2024-11-07T10:00:00"),
        endTime: new Date("2024-11-07T14:15:00"),
        duration: 15300, // 4h 15m
        isRunning: false,
        createdAt: new Date(),
      },
      {
        id: "entry-4",
        projectId: "proj-4",
        description: "Database schema design and optimization",
        startTime: new Date("2024-11-07T08:00:00"),
        endTime: new Date("2024-11-07T13:30:00"),
        duration: 19800, // 5h 30m
        isRunning: false,
        createdAt: new Date(),
      }
    ];

    entries.forEach(entry => {
      this.timeEntries.set(entry.id, entry);
    });
  }

  // Projects
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = randomUUID();
    const newProject: Project = {
      ...project,
      id,
      createdAt: new Date(),
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined> {
    const existing = this.projects.get(id);
    if (!existing) return undefined;

    const updated: Project = { ...existing, ...project };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: string): Promise<boolean> {
    // Also delete associated time entries
    const projectEntries = Array.from(this.timeEntries.values()).filter(entry => entry.projectId === id);
    projectEntries.forEach(entry => this.timeEntries.delete(entry.id));
    
    return this.projects.delete(id);
  }

  async getProjectsWithStats(): Promise<ProjectWithStats[]> {
    const projects = await this.getProjects();
    const now = new Date();
    
    return projects.map(project => {
      const entries = Array.from(this.timeEntries.values()).filter(entry => entry.projectId === project.id);
      const totalSeconds = entries.reduce((sum, entry) => sum + (entry.duration || 0), 0);
      const totalHours = totalSeconds / 3600;
      const totalRevenue = totalHours * parseFloat(project.hourlyRate);
      const budgetHours = parseFloat(project.budgetHours);
      const budgetProgress = (totalHours / budgetHours) * 100;
      
      // Calculate timeline progress
      const startDate = new Date(project.createdAt);
      const endDate = new Date(project.deadline);
      const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const daysPassed = Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const daysLeft = Math.max(0, totalDays - daysPassed);
      const timelineProgress = Math.min(100, (daysPassed / totalDays) * 100);
      
      // Calculate expected hours based on timeline
      const expectedHours = (daysPassed / totalDays) * budgetHours;
      
      // Calculate weekly hours (last 7 days)
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const weeklyEntries = entries.filter(entry => new Date(entry.startTime) >= weekAgo);
      const weeklySeconds = weeklyEntries.reduce((sum, entry) => sum + (entry.duration || 0), 0);
      const weeklyHours = weeklySeconds / 3600;
      
      // Determine status
      let status: 'ahead' | 'on-track' | 'behind' = 'on-track';
      const variance = totalHours - expectedHours;
      if (variance > budgetHours * 0.1) status = 'behind';
      else if (variance < -budgetHours * 0.05) status = 'ahead';
      
      return {
        ...project,
        totalHours,
        totalRevenue,
        budgetProgress,
        timelineProgress,
        weeklyHours,
        expectedHours,
        status,
        daysLeft,
        weeklyProgress: Math.min(100, (weeklyHours / (budgetHours / (totalDays / 7))) * 100),
        monthlyProgress: Math.min(100, (totalHours / (budgetHours * (daysPassed / totalDays))) * 100),
      };
    });
  }

  // Time Entries
  async getTimeEntries(): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values()).sort((a, b) => 
      new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
    );
  }

  async getTimeEntry(id: string): Promise<TimeEntry | undefined> {
    return this.timeEntries.get(id);
  }

  async getTimeEntriesWithProjects(): Promise<TimeEntryWithProject[]> {
    const entries = await this.getTimeEntries();
    return entries.map(entry => {
      const project = this.projects.get(entry.projectId);
      if (!project) throw new Error(`Project not found for entry ${entry.id}`);
      
      const hours = (entry.duration || 0) / 3600;
      const total = hours * parseFloat(project.hourlyRate);
      
      return {
        ...entry,
        project,
        total,
      };
    });
  }

  async getTimeEntriesForProject(projectId: string): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values())
      .filter(entry => entry.projectId === projectId)
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
  }

  async createTimeEntry(timeEntry: InsertTimeEntry): Promise<TimeEntry> {
    const id = randomUUID();
    const newEntry: TimeEntry = {
      ...timeEntry,
      id,
      createdAt: new Date(),
    };
    this.timeEntries.set(id, newEntry);
    return newEntry;
  }

  async updateTimeEntry(id: string, timeEntry: UpdateTimeEntry): Promise<TimeEntry | undefined> {
    const existing = this.timeEntries.get(id);
    if (!existing) return undefined;

    const updated: TimeEntry = { ...existing, ...timeEntry };
    this.timeEntries.set(id, updated);
    return updated;
  }

  async deleteTimeEntry(id: string): Promise<boolean> {
    return this.timeEntries.delete(id);
  }

  async getRunningTimeEntry(): Promise<TimeEntry | undefined> {
    return Array.from(this.timeEntries.values()).find(entry => entry.isRunning);
  }

  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const entries = Array.from(this.timeEntries.values());
    
    // Today's hours
    const todayEntries = entries.filter(entry => new Date(entry.startTime) >= todayStart);
    const todaySeconds = todayEntries.reduce((sum, entry) => sum + (entry.duration || 0), 0);
    const todayHours = todaySeconds / 3600;

    // Week's hours
    const weekEntries = entries.filter(entry => new Date(entry.startTime) >= weekStart);
    const weekSeconds = weekEntries.reduce((sum, entry) => sum + (entry.duration || 0), 0);
    const weekHours = weekSeconds / 3600;

    // Active projects
    const activeProjects = Array.from(this.projects.values()).filter(p => p.isActive).length;

    // Total revenue
    const totalRevenue = entries.reduce((sum, entry) => {
      const project = this.projects.get(entry.projectId);
      if (!project) return sum;
      const hours = (entry.duration || 0) / 3600;
      return sum + (hours * parseFloat(project.hourlyRate));
    }, 0);

    return {
      todayHours,
      weekHours,
      weekTarget: 40, // Standard 40-hour week
      activeProjects,
      totalRevenue,
      weeklyProgress: (weekHours / 40) * 100,
      monthlyProgress: 75, // Calculated based on monthly targets
    };
  }
}

export const storage = new MemStorage();
